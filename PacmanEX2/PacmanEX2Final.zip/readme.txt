sagi ben noon- 206446288
ofir cohen- 208711234

*We add an option  in the settings to change the game speed
*When you change the speed, there will be a delay of 1.5 seconds(we put sleep(1500).)
* when you successfuly finish a map the difficult of the game will increase(remmber that you can change the level any time)
*We add an option in the settings to change the game difficult
*If the player is not reachable by the ghost, the ghosts wil not move. (In the best movment)